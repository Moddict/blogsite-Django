# Django-blog-app
This is the blog app with Django Python
